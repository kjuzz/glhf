long square(long a){
	int res=0;
	for(int i=0;i<a;i++){
		res+=a;
	}
	return res;
}
